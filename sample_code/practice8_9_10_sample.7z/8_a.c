#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int random(void);
void print_result(void);
void move_t(void);
void move_h(void);

char start[30] = "BANG!!! AND THEY'RE OFF!!!!!", ouch[10] = "OUCH!!!", h_win[25] = "Hare wins. Yuch.";
char t_win[25] = "TORTOISE WINS!!! YAY!!!", tie[15] = "It's a tie.";
char t_move_type[3][25] = {"Tortoise Fast plod", "Tortoise Slip", "Tortoise Slow plod"};
char h_move_type[5][25] = {"Hare Sleep", "Hare Big hop", "Hare Big slip", "Hare Small hop", "Hare Small slip"};
int coord_t = 1, coord_h = 1;
int status_t = -1, status_h = -1;

int main(void)
{
	while(1)
	{
		print_result();
		move_t();
		move_h();
	}	
}

/*		produce a random number from 0~9	*/
int random(void)
{
	int i;
	time_t now;
	time(&now);
	srand(time(NULL));
	i = rand() % 10;
	return i;
}

/*		print out the result				*/
void print_result(void)
{
	int counter1;
	system("cls");
	if (status_t == -1 && status_h == -1) printf("%s\n", start);
	else
	{
		printf("%s\n", t_move_type[status_t]);
		printf("%s\n", h_move_type[status_h]);
		if (coord_h == coord_t && coord_h != 25) printf("\n%s\n", ouch);
	}
	if (coord_h == 25 && coord_t == 25) printf("\n%s", tie);
	else if (coord_h == 25) printf("\n%s\n", h_win);
	else if (coord_t == 25) printf("\n%s\n", t_win);
	for (counter1 = 1; counter1 <= 25; counter1++) printf(" %2d", counter1);
	printf("\n");
	for (counter1 = 2; counter1 <= coord_t; counter1++) printf("   ");
	printf("  T\n");
	for (counter1 = 2; counter1 <= coord_h; counter1++) printf("   ");
	printf("  H\n");
	if (coord_h == 25 || coord_t == 25) exit(1);
	system("pause");
	return;
}

/*		tortoise move						*/
void move_t()
{
	int i = random();
	if (i >= 0 && i <= 4)
	{
		status_t = 0;
		if (coord_t + 3 > 25) coord_t = 25;
		else coord_t += 3;
	}
	else if (i >= 5 && i <= 6)
	{
		status_t = 1;
		if (coord_t - 6 <= 1) coord_t = 1;
		else coord_t -=6;
	}
	else
	{
		status_t = 2;
		coord_t++;
	}
}

/*		hare move							*/
void move_h(void)
{
	int i = random();
	if (i == 0 || i == 1) status_h = 0;
	else if (i == 2 || i == 3)
	{
		status_h = 1;
		if (coord_h + 9 > 25) coord_h = 25;
		else coord_h += 9;
	}
	else if (i == 4)
	{
		status_h = 2;
		if (coord_h - 12 < 1) coord_h = 1;
		else coord_h -= 12;
	}
	else if (i >= 5 && i <= 7)
	{
		status_h = 3;
		coord_h++ ;
	}
	else
	{
		status_h = 4;
		if (coord_h - 2 < 1) coord_h = 1;
		else coord_h -= 2;
	}
}
