#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SPAM	50
#define lenKey 	25
#define numKey 	200
#define BUFFER  500
/***** Variables *****/
int  key_size;
char key_name[numKey][lenKey];
int  key_weight[numKey];
int  key_oc[numKey];

char line[BUFFER];
char buf[BUFFER];

int  mode;  // mode0: -oc  // mode1: -spam  

/***** Functions *****/
void clean_oc();
void compare_key( char *token );
void parse_Spamkey( char *keyword_file_name );
void parse_Email( char *email_file_name );

/***** Function body *****/
int main(int argc, char **argv)
{
	int i, j;
	for( j=1; j<argc; ++j )
		if( !strcmp(argv[j],"-oc") )
			mode = 0;
		else if( !strcmp(argv[j],"-spam") )
			mode = 1;
	// initialization
	i = 1;
	key_size = 0;

	while( i<argc )
	{
		if( !strcmp(argv[i],"-k") )
			parse_Spamkey(argv[++i]);
		else if( !strcmp(argv[i],"-e") )
			parse_Email(argv[++i]);
		else if( !strncmp(argv[i], "-k", 2) )
		{
			int num = atoi(argv[i]+2);
			for( j=0; j<num; ++j )
				parse_Spamkey(argv[++i]);
		}
		else if( !strncmp(argv[i], "-e", 2) )
		{
			int num = atoi(argv[i]+2);
			for( j=0; j<num; ++j )
				parse_Email(argv[++i]);
		}
		i++;
	}
	
	return 0;
} 

void clean_oc()
{
	int i;
	for( i=0; i<key_size; ++i )
		key_oc[i] = 0;
}

void compare_key( char *token )
{
	int i;
	for( i=0; i<key_size; ++i )
		if( !strcmp( token, key_name[i]) )
		{
			key_oc[i]++;
			break;
		}
}

void parse_Spamkey( char *keyword_file_name )
{
	//printf("parse spamkey %s\n", keyword_file_name);
	FILE *keyFILE;
	keyFILE = fopen( keyword_file_name, "r");
	if( keyFILE == NULL ) 
	{
		printf("*Error opening file \"%s\"\n", keyword_file_name);
		return;
	}

	while(1)
	{
		int weight;
		fscanf( keyFILE, "%d", &weight);
		if( weight == -999 ) break;
		fscanf( keyFILE, "%s", key_name[key_size]);
		key_weight[key_size] = weight;
		key_size++;
	}

	return;
}

void parse_Email( char *email_file_name )
{
	clean_oc();
	FILE *mailFILE;
	mailFILE = fopen( email_file_name, "r");
	if( mailFILE == NULL ) 
	{
		printf("*Error opening file \"%s\"\n", email_file_name);
		return;
	}

	int i;
	while( fgets(line, sizeof(line), mailFILE) != NULL )
	{
		for( i=0; i<sizeof(line); ++i )
		{
			if( line[i]<65 || (line[i]>90 && line[i]<97) || line[i]>122 ) // not alphabet
				line[i] = ' ';
			else if( line[i] < 97 )
				line[i] += 32;
		}
		char *token;
		token = strtok( line, " ");
		while( token!= NULL )
		{
			compare_key(token);
			token = strtok( NULL, " ");
		}
		memcpy( line, buf, sizeof(line) );
	}

	int totalcost = 0;
	printf("\n###### Email: %s #################################\n", email_file_name );	
	for( i=0; i<key_size; ++i )
	{
		if( key_oc[i]!=0 )
		{
			if( !mode )
				printf("%s = %d\n", key_name[i], key_oc[i]);
			totalcost += key_oc[i]*key_weight[i];
		}
	}
	if( mode )
	{
		printf("cost: %d\n", totalcost );
		if( totalcost>SPAM )
			printf("%s is marked as spam.\n", email_file_name );
		else
			printf("This is a normal email.\n");
	}
	printf("###########################################################\n");

}
