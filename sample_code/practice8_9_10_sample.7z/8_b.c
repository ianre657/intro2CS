#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

/*	function used	*/
int random(void);
void print_result(void);
void move_t(void);
void move_h(void);
void gen_terrain(void);
void print(void);
void print_ruler(int offset_ruler);
void print_terrain(int offset_terrain);
void print_character(int offset_character);

/*	initilization	*/
char bang[30] = "BANG!!! AND THEY'RE OFF!!!!!", h_win[25] = "Hare wins. Yuch.";	//those are banner
char t_win[25] = "TORTOISE WINS!!! YAY!!!", tie[15] = "It's a tie.";
char t_move_type[3][25] = {"Tortoise Fast plod", "Tortoise Slip", "Tortoise Slow plod"};
char h_move_type[6][25] = {"Hare Sleep", "Hare Big hop", "Hare Big slip", "Hare Small hop", "Hare Small slip", "HURT!!!"};
int coord_t = 1, coord_h = 1;	//store current coordinate
int status_t = -1, status_h = -1;	//store last move type
int terrain[60];	//store the terrain type
int special_t = 0;
int h_bighop = 0;	//hare bighop action controller
int h_sleep_ctrl = 0, h_river = 0, h_forest = 0, h_hurt = 0, spd_ctrl = 1;
int print_spec = -1;	//use to control print how many lines will be stated in function

/*	main structure	*/
int main(void)
{
	gen_terrain();	//generate terrain
	while(1)	//continue query only when one reached the goal
	{
		print_spec = -1;	//initilized again
		print_result();
		if (coord_t == coord_h && status_t != -1) h_hurt = 1;	//check if both were at the same square last round
		move_t();
		move_h();
	}	
}

/*	produce a random number from 0~9	*/
int random(void)
{
	int i;
	srand(time(NULL));
	i = rand() % 10;
	return i;
}

/*	print out the result	*/
void print_result(void)
{
	system("cls");	//clean the screen and print the data again to update
	/*	print banner	*/
	if (status_t == -1 && status_h == -1) printf("%s\n", bang);	//start statement
	else
	{
		printf("%s\n", t_move_type[status_t]);	//print tortoise last move type
		printf("%s\n", h_move_type[status_h]);	//print hare last move type
	}
	if (coord_h == 60 && coord_t == 60) printf("\n%s", tie);	//when two character reach the goal at same time
	else if (coord_h == 60) printf("\n%s\n", h_win);	//hare reach the goal
	else if (coord_t == 60) printf("\n%s\n", t_win);	//same as above
	print();	//print ruler, terrain, character
	if (coord_h == 60 || coord_t == 60) exit(1);	//terminate the program when one or both reach the goal
	system("pause");	//waiting for user query
	return;
}

/*	tortoise move	*/
void move_t()
{
	int i = random();	//choose random number
	if (terrain[coord_t - 1] == 0) special_t = 1;	//if tortoise reach river last round
	if ((i >= 0 && i <= 4) || special_t == 1)	//50% of possibility or last round reached river to fast plod(+3)
	{
		special_t = 0;	//clear the special action
		status_t = 0;	//state as '0' fast plod in array
		if (coord_t + 3 > 60) coord_t = 60;	//restrict the character not to cross the board
		else coord_t += 3;
	}
	else if (i >= 5 && i <= 6)	//20% of possibility to slip(-6)
	{
		status_t = 1;	//state as '1' slip in array
		if (coord_t - 6 <= 1) coord_t = 1;	//restrict not to across the board
		else coord_t -=6;
	}
	else	//30% of possibility to slow plod(+1)
	{
		status_t = 2;	//state as '2' slow plod in array
		coord_t++;
	}
	return;
}

/*		hare move	*/
void move_h(void)
{
	int i = random();
	/*	check if head to head	*/
	if (h_hurt == 1)
	{
		status_h = 5;
		h_hurt = 0;
		if (spd_ctrl == 2) spd_ctrl = 1;
		if (h_bighop ==1) h_bighop = 0;
		return;
	}
	/*	execute if contiously big hop	*/
	if (h_bighop == 2)
	{
		h_bighop = 0;
		status_h = 0;
		if (spd_ctrl == 2) spd_ctrl = 1;
		return;
	}
	/*		check if reach river			*/
	if (terrain[coord_h - 1] == 0 || spd_ctrl == 2)
	{
		if (terrain[coord_h - 1] == 0 && spd_ctrl == 2) h_river = 2;
		else if (spd_ctrl == 2)
		{
			if (h_river == 2) h_river--;
			else
			{
				h_river = 0;
				spd_ctrl = 1;
			}
		}
		else
		{
			spd_ctrl = 2;
			h_river = 2;
		}
	}
	/*	check if reach forest			*/
	if (terrain[coord_h - 1] == 1 && h_sleep_ctrl == 0)
	{
		i = 0;
		h_sleep_ctrl = 1;
		status_h = 0;
		if (h_bighop == 1) h_bighop = 0;
		return;
	}
	else h_sleep_ctrl = 0;
	/*	move by random	*/
	if (i == 0 || i == 1) status_h = 0;
	else if (i == 2 || i == 3)
	{
		status_h = 1;
		h_bighop++;
		if (coord_h + (int)(9 / spd_ctrl) > 60) coord_h = 60;
		else coord_h += (int)(9 / spd_ctrl);
	}
	else if (i == 4)
	{
		status_h = 2;
		if (coord_h - (12 / spd_ctrl) < 1) coord_h = 1;
		else coord_h -= (12 / spd_ctrl);
	}
	else if (i >= 5 && i <= 7)
	{
		status_h = 3;
		coord_h += (int)(1 / spd_ctrl);
	}
	else
	{
		status_h = 4;
		if (coord_h - (int)(2 / spd_ctrl) < 1) coord_h = 1;
		else coord_h -= (int)(2 / spd_ctrl);
	}
	/*	detect continuous big hop	*/
	if (h_bighop == 1 && i != 2 && i != 3) h_bighop = 0;
	return;
}

/*	generate terrain	*/ // 0~2 represent river; forest; slade in array
void gen_terrain(void)
{
	int i, j;
	srand(time(NULL));
	/*	initilize terrain	*/
	for (i = 0; i <= 59; i++) terrain[i] = -1;	//initialize all the terrain to -1(none)
	/*	generate river	*/	//12 square of river needed
	while(1)
	{
		j = 0;
		terrain[rand() % 60] = 0;	//choose from terrain[1 ~ 59] and assign to river
									//(don't need to check the content of array since it's either 0 or -1)
		for (i = 0; i <= 59; i++) j += terrain[i];	//sum up the content of array
		if (j == -48) break;	//since there should be 12 '0' and 48 '-1' when the operation finished, the sum should be -48 
	}
	/*	generate forest	*/	//12 square of forest needed
	while(1)
	{
		j = 0;
		i = rand() %60;
		if (terrain[i] == 0) continue;	//if that index is assigned to river choose again
		terrain[i] = 1;	//if not assign to forest
		for (i = 0; i <= 59; i++) j += terrain[i];	//sum up
		if (j == -24) break;	//same logic 12 * 0 + 12 * 1 + 36 * -1 = -24 
	}
	/*	generate slade	*/ //36 square of slade needed
	for (i = 0; i <= 59; i++)	//assign the rest to slade
	{
		if (terrain[i] != -1) continue;
		terrain[i] = 2;
	}
	/*	PSA: to avoid certain situation, it's best to set the start point to slade	*/
	return;
}

/*	check what type should be printed according to the position of character	*/
void print(void)
{
	if (coord_h <= 25 && coord_t <= 25) print_ruler(1);	//if both character are between 1~25 then only print 1~25
	else
	{
		print_spec = (int)(abs(coord_h - coord_t) /25 + 1); //control how many lines should be printed
		if (coord_h > coord_t) print_ruler(coord_t);	//check who is advantaged
		else print_ruler(coord_h);	//same position included
	}
	return;
}

/*	print ruler	*/
void print_ruler(int offset_ruler)
{
	if (print_spec == 0) return;	/*	check if all lines are printed
										-1 and 1 if only one line to be printed, and so on	*/
	int end_ruler = offset_ruler + 25;	//those are buffer
	int buffer_ruler = end_ruler;
	if (end_ruler > 60) end_ruler = 61;	//the ruler should only printed to 60 for maxma
	for (; offset_ruler <= end_ruler - 1; offset_ruler++) printf(" %2d", offset_ruler);
	printf("\n");
	if (end_ruler == 61) end_ruler = buffer_ruler;	//recover from buffer to pass to next function
	print_terrain(end_ruler - 25);
	return;
}

/*	print terrain	*/
void print_terrain(int offset_terrain)	
{
	int end_terrain = offset_terrain + 25;	//buffer again
	int buffer_terrain = end_terrain;
	if (end_terrain > 60) end_terrain = 61;	//the maxma index of terrain is 59, restrict in order to prevent crash
	for (--offset_terrain; offset_terrain <= end_terrain - 2; offset_terrain++)	//print out the terrain depend on array
	{
		switch (terrain[offset_terrain])
		{
			case 0: printf("  R");
					break;
			case 1: printf("  F");
					break;
			case 2: printf("  S");
		}
	}
	printf("\n");
	if (end_terrain == 61) end_terrain = buffer_terrain;	//same logic above
	print_character(end_terrain - 25);
	return;
}

/*		print hare and tortoise			*/
void print_character(int offset_character)
{
	int start = offset_character;	//buffer
	if (coord_t >= start && coord_t <= start + 24)	//check if character should be printed in this line
	{
		for (++offset_character; offset_character <= coord_t; offset_character++) printf("   ");
		printf("  T\n");
	}
	else printf("\n");	//if not, just leave a blank line
	if (coord_h >= start && coord_h <= start +24)	//same logic above
	{
		for (offset_character = start + 1; offset_character <= coord_h; offset_character++) printf("   ");
		printf("  H\n");
	}
	else printf("\n");
	if (coord_h <= 25 && coord_t <= 25) return;	//if only one line should be printed then return
	else
	{
		print_spec--;	//update the controller
		print_ruler(start + 25);	//pass new value
	}
	return;
}
	
	
