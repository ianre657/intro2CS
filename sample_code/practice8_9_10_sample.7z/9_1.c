#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_LEN 1000
#define MAX_ROW 1000

double total_weight;
int klength,elength;
char keyword[MAX_ROW][MAX_LEN];
char email[MAX_ROW][MAX_LEN];
void input_keyFile(char *keyFile);
void input_emailFile(char *emailFile);
void tolower_case(int elength);
double compute_weight(int key_weight[],int fkeyword[]);
void print_statistics(int key_weight[],int fkeyword[],char *emailFile);
void print_judge();

int main(int argc,char *argv[])
{
	int i;
    input_keyFile(argv[2]);
    input_emailFile(argv[4]);
    tolower_case(elength);
    int key_weight[klength/2],fkeyword[klength/2];
    total_weight=compute_weight(key_weight,fkeyword);
    
	for(i=0;i<argc;i++)
    {
    	if(strcmp(argv[i],"-oc")==0)
    	    print_statistics(key_weight,fkeyword,argv[4]);
    	else if(strcmp(argv[i],"-spam")==0)
            print_judge();	
	}
    system("pause");
    return 0;
}
void input_keyFile(char *keyFile)
{
	int i,j;
	FILE *fp;
	fp=fopen(keyFile,"r");
    if(!fp)
	{
    	printf("Error opening file\n");
        return;
	}
	else
    {
        i=0;
        while(1)
        {
            fscanf(fp,"%s",keyword[i]);
            if(!strcmp(keyword[i],"-999"))
            {
                i--;
                break;
            }
            i++;
        }
        fclose(fp);
    }
    klength=i+1;
}
void input_emailFile(char *emailFile)
{
	int i,j;
	FILE *fp;
	fp=fopen(emailFile,"r");
	if(!fp)
    {
    	printf("Error opening file\n");
    	return;
	}
    else
    {
       j=0;
       while(fscanf(fp,"%[a-zA-Z]%*[^a-zA-Z]",email[j])!=EOF)
       {
            j++;
       }
       fclose(fp);
    }
	elength=j+1;
}
void tolower_case(int elength)
{
	int k,l;
	for(k=0;k<elength;k++)
    {
    	char *c=email[k];
    	l=0;
    	while(*c!='\0')
    	{
    	    email[k][l]=tolower(*c);
    	    c++;
    	    l++;
        }
    }
}
double compute_weight(int key_weight[],int fkeyword[])
{
	int i,j,k;
    j=0;
    for(i=0;i<klength;i+=2)
    {
        key_weight[j]=atoi(keyword[i]);
        j++;
    }
    for(i=0;i<klength/2;i++)
        fkeyword[i]=0;
    k=0;
    for(i=0;i<klength;i+=2)
    {

        for(j=0;j<elength;j++)
        {
            if(strcmp(email[j],keyword[i+1])==0)
                fkeyword[k]=fkeyword[k]+1; 
        }
        k++;
    }
    double spam_weight=0.0;
    for(i=0;i<klength/2;i++)
    {
        spam_weight+=(double)(fkeyword[i]*key_weight[i])/(double)elength;
    }
    return spam_weight;
}
void print_statistics(int key_weight[],int fkeyword[],char *emailFile)
{
	int i,j;
	printf("***The statistics for the occurrences of each keyword in %s ***\n",emailFile);
	printf("weight frequency    keyword\n");
    j=1;
    for(i=0;i<klength/2;i++)
    {
        printf(" %2d ",key_weight[i]);
        printf(" %9d ",fkeyword[i]);
        printf(" %11s\n",keyword[j]);
        j+=2;
	}
    printf("*****************************************\n");
    printf("total spam weight: %lf\n",total_weight);
}
void print_judge()
{
	if(total_weight>0.85)
	   printf("It's a spam email\n");
	else
	   printf("It's a normal email\n");
}
