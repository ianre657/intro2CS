#include<stdio.h>
#include <stdlib.h>


int main(int argc, char** argv)
{
    unsigned long long int total;
    int l_value, r_value, ll_value, lr_value;
    
    int *overlap = (int*)malloc(500000*(sizeof(int)));
    
    unsigned long long int *table = (unsigned long long int*)malloc(100000*(sizeof(unsigned long long int)));
    table[0] = table[1] = 0;
    table[2]=1;
    for(int i = 3; i < 100000; i++){
        table[i]=table[i-1]+(i-1);
    }
    
    FILE *input_1;
    input_1= fopen(argv[1], "r");
    ll_value=lr_value=-1;
    total = 0;
    for (int i = 0; i < 500000; i++) {
        overlap[i] = 0;
    }
    while(fscanf(input_1, "%d%d", &l_value ,&r_value)){
        if(ll_value == l_value && lr_value == r_value){
            break;
        }
        for(int i = l_value; i < r_value; i++){
            overlap[i]++;
        }
        ll_value = l_value;
        lr_value = r_value;
    }
    for(int i = 0; i < 500000; i++){
        total+=table[overlap[i]];
        
    }
    printf("line_set1: %lld\n", total);
    fclose(input_1);
    return 0;
    
}
