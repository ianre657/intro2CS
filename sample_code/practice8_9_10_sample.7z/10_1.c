#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/*	global variation	*/

struct	//structure to save left and right end point
{
	int left, right;
}line[180000], buffer;
int end;	//use two save how many lines

/*	function used	*/
void store_file	(const int argc, const char **argv);
void calc_brute(void);
double calc_sorted(void);
int q_sort(int l, int r);
void q_sort_p(int l, int r);

/*	main structure	*/
void main(const int argc, const char **argv)
{
	double overlap;
	time_t t[4];	//to save how many time is used
	store_file(argc, argv);
	printf("Please wait while proccessing.\n");
	printf("It may take up to serveral minutes, please be patient....\n");
	t[0] = clock();
	calc_brute();
	t[1] = clock();
	q_sort_p(0, end - 2);
	t[2] = clock();
	overlap = calc_sorted();
	t[3] = clock();
	system("cls");
	printf("The overlap is %.0f\n", overlap);
	printf("The time used without sorting is %d clicks (%f seconds)\n", t[1] - t[0], (float)(t[1] - t[0])/ CLOCKS_PER_SEC);
	printf("The time used on sorting is %d clicks (%f seconds)\n", t[2] - t[1], (float)(t[2] - t[1])/ CLOCKS_PER_SEC);
	printf("The time used on calculating after sorting is %d clicks (%f seconds)\n", t[3] - t[2], (float)(t[3] - t[2])/ CLOCKS_PER_SEC);
	printf("The speed after sorted is %fx faster than the original data", ((float)(t[1] - t[0])) / ((float)(t[3] - t[1])) );
	return;
}

/*	store the input file	*/
void store_file(const int argc, const char **argv)
{
	int counter1;
	FILE *p_file;
	p_file = fopen(*(argv + 1), "r");
	if (p_file == NULL)
	{
		printf("Error opening file.\n");
		printf("Please make sure you follow the following parameter\n");
		printf("line_overlap xxx.txt");
		exit(1);
	}
	for (counter1 = 0; !feof(p_file); counter1++)
	{
		fscanf(p_file, "%d%d", &line[counter1].left, &line[counter1].right);
	}
	end = counter1 + 1;
	return;
}

/*	calculate the overlap O(n^2)	*/
void calc_brute(void)
{
	int counter1, counter2;
	double overlap;
	for (counter1 = 0; counter1 <= end - 2; counter1++)
	{
		for (counter2 = counter1 + 1; counter2 <= end - 1; counter2++)
		{
			if (line[counter1].left <= line[counter2].left)
			{
				if (line[counter1].right <= line[counter2].left) continue;
				else
				{
					if (line[counter2].right >= line[counter1].right) overlap += (line[counter1].right - line[counter2].left);
					else overlap += (line[counter2].right - line[counter2].left);
				}				
			}
			else
			{
				if (line[counter2].right <= line[counter1].left) continue;
				else
				{
					if (line[counter1].right >= line[counter2].right) overlap += (line[counter2].right - line[counter1].left);
					else overlap += (line[counter1].right - line[counter1].left);
				}	
			}
		}
	}
	overlap = 0;
	return;
}

/*	calculate the overlap (sorted)	*/

double calc_sorted(void)
{
	int counter1, counter2;
	double overlap;
	for (counter1 = 0; counter1 <= end - 2; counter1++)
	{
		for (counter2 = counter1 + 1; counter2 <= end - 1; counter2++)
		{
			if (line[counter1].right <= line[counter2].left)
			{
				counter2 = end;
				continue;
			}
			else
			{
				if (line[counter2].right >= line[counter1].right) overlap += (line[counter1].right - line[counter2].left);
				else overlap += (line[counter2].right - line[counter2].left);
			}				
		}
	}
	return overlap;
}

/*	quick sort prototype	*/
void q_sort_p(int l, int r)
{
	int middle;
	if (l >= r) return;
	middle = q_sort(l, r);
	q_sort_p(l, middle - 1);
	q_sort_p(middle + 1, r);
}

/*	sort the left point first (quick sort)	*/
int q_sort(int l, int r)
{
	buffer = line[l];
	if (l >= r) return;
	while(1)
	{
		if (l >= r) break;
		while(1)
		{
			if (l >= r) break;
			if (line[r].left <= buffer.left)
			{
				line[l] = line[r];
				l++;
				break;
			}
			else r--;
		}
		if (l >= r) break;
		while(1)
		{
			if (l >= r) break;
			if (line[l].left >= buffer.left)
			{
				line[r] = line[l];
				r--;
				break;
			}
			else l++;
		}
		if (l >= r) break;
	}
	line[l] = buffer;
	return l;
}

