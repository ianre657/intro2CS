#include <stdio.h>
#include <stdlib.h>
#include <string.h>
char ipt[ 1000 ] , opt[ 1000 ] ;
int cnt ;
int len_i , len_o ;
int i , j , k , l;
int idx ;
void chk(int hd , int end){
	int tf = 1 ;
	if ( ipt[ hd ] == '0' ){		//0 start
		for ( k = hd ; k <= end ; k++ )
			if ( ipt[ k ] != '0' ){
				tf = 0 ;
				break ;
			}
		if ( tf == 1 ){	// 0000000
			opt[ idx ] = '0' ;
			idx++ ;
		}
		else{			//00000123
			for ( l = k ; l <= end ; l++ ){
				opt[ idx ] = ipt[ l ] ;
				idx++ ;
			}
		}
	}
	else if ( ipt[ hd ] >= '1' && ipt[ hd ] <= '9' ){	//1~9 start
		for ( k = hd ; k <= end ; k++ ){
			opt[ idx ] = ipt[ k ] ;
			idx++ ;
		}
	}
	else if ( ipt[ hd ] == '-' ){			//negative
		for ( k = hd + 1 ; k <= end ; k++ )
			if ( ipt[ k ] != '0' ){		
				tf = 0 ;
				break ;
			}
		if ( tf == 1 ){				//-00000000
			opt[ idx ] = '0' ;	
			idx++ ;
		}
		else{						//-000123
			opt[ idx ] = '-' ;
			idx++ ;
			for ( l = k ; l <= end ; l++ ){
				opt[ idx ] = ipt[ l ] ;
				idx++ ;
			}
		}
	}
	opt[ idx ] = ' ' ;
	idx++ ;
}
int main(){
	
	printf("Put some integers inside your message and I can find out all integers for you.\n") ;
	printf("Your Input:") ;
	gets(ipt) ;
	idx = 0 ;	cnt = 0 ;
	len_i = strlen(ipt) ;
	for ( i = 0 ; i < len_i ; i++ ){	//go thro all input
	if ( ipt[ i ] >= '0' && ipt[ i ] <= '9' || ipt[ i ] == '-' ){	//get the head
			for ( j = i + 1 ; j < len_i ; j++ )
					if ( ipt[ j ] < '0' || ipt[ j ] > '9' )				//get the end
					break ;			
			chk(i,j-1) ;
			i = j - 1 ;
		}
	}
	len_o = strlen(opt) ;
	for ( i = 0 ; i < len_o ; i++ )
		if ( opt[ i ] == ' ' )
			cnt++ ;
	printf("I find %d integers in total.\n", cnt) ;	
	puts(opt) ;
	for ( i = 0 ; i < len_o ; i++ )
		opt[ i ] = '\0' ;

	return 0 ;
}

