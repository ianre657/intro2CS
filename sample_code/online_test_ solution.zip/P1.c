#include <stdio.h>
 int main(){
	 char ch[1000];
	 int index_ch=-1;
	 int int_cnt=0;
	 int integer=0;
	 int i;
	 int a_cnt,d_cnt;
	 
	 while(1){
		 printf("1: Input an integer.\n");
	 	 printf("2: Quit the program.\n");
		 int c;
		 scanf("%d", &c);
		 if(c==2) {
		 	 break;
		 }
		 else if(c==1){
		 	 for(i=0;i<1000;i++) ch[i]='\0';
			 a_cnt=0;
			 d_cnt=0;
			 int_cnt=0;
			 index_ch=-1;
			 integer=0;
			 printf("Please input an integer:");
			 int_cnt=scanf("%d",&integer);
			 //printf("flag1 %d\n",int_cnt);
			 while((ch[++index_ch]=getchar())!='\n'){
			 	//printf("flag2\n");
			 }
			 for(i=0;i<=index_ch;i++){
				 if(ch[i]=='a'||ch[i]=='A') a_cnt++;
				 if(ch[i]=='d'||ch[i]=='D') d_cnt++;
			 }
			 //printf("flag3\n");
			 if(int_cnt==0 && index_ch==00) printf("Your input is illegal.\n");
			 else if(int_cnt==1 && index_ch==0) {
				 printf("The input integer is %d.\n",integer);
			 }
			 else if(int_cnt==1 && index_ch>0) {
				 printf("The input integer is %d.\n",integer);
				 printf("There are %d useless characters in your input.\n",index_ch);
				 if(a_cnt!=0) printf("Among themm there are %d 'a' and 'A' characters.\n",a_cnt);
				 if(d_cnt!=0) printf("Among themm there are %d 'd' and 'D' characters.\n",d_cnt);
			 }
			 else if(int_cnt==0 && index_ch>0) {
				 printf("There are %d useless characters in your input.\n",index_ch);
				 if(a_cnt!=0) printf("Among themm there are %d 'a' and 'A' characters.\n",a_cnt);
				 if(d_cnt!=0) printf("Among themm there are %d 'd' and 'D' characters.\n",d_cnt);
			 }
		 }
		 else {
		 	printf("Please type 1 or 2. try again!\n");	
		 	fflush(stdin);
		 }
	 }
	 return 0;
 }
